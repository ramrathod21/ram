const productModel = require("../../models/product.model");
const User = require("../../models/user.model")


//create product only suppliers
const createProduct = async (Name,Description,category,image,supplier,basePrice,tags,location,sku,moq,stock ) =>{
    const user = await User.findById(supplier);
    if(!user){
        throw Error ('user not found');
    }
    if(user.userRole !== 'supplier')
    {
        throw Error ('user is not a supplier');
    }
    const newProduct = new productModel({ 
        Name,
        Description,
        category,
        images: image,
        supplier,
        basePrice,
        tags,
        location,
        sku,
        moq,
        stock
    });
    await newProduct.save();
    return newProduct;
}


//edit product only supplier
const editProductSupplier = async (productId, supplierCode) => {
  try {
    const product = await Product.findByIdAndUpdate(productId, { supplierCode }, { new: true });
    return product;
  } catch (error) {
    throw error;
  }
};
//delete product only supplier
if (!updatedProduct) {
      throw new Error('Product not found');
    }

   { return updatedProduct;
     catch (error) {
    throw new Error(`Failed to remove supplier code: ${error.message}`);
  }
};

module.exports = {
  removeProductSupplier,
};


//get all products of the supplier







//Get all products for all users
const commonProducts = async (userId) =>{
    const user = await User.findById(userId);
    if(!user){
        throw Error ('user not found');}
     const allProducts = await productModel.find()
     return allProducts

}





//Get product by Category







//Get product details





//search products


module.exports = {createProduct,commonProducts,editProductSupplier};