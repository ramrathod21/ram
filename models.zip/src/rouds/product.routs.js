const express = require('express');
const router = express.Router();
const productController = require('../controller/product.controller');
const { commonProducts } = require('../services/product.services');


router.post('/create', productController.createProduct);
router.get('/products', productController,commonProducts);
module.exports = router;