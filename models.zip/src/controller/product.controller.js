const productService = require('../services/product.services');
const createProduct = async (res, req) => {
    try{
        const { Name, Description, category, image, supplier, basePrice, tags, location, sku, moq, stock } = req.body;
        const newProduct = await productService.createProduct(Name, Description, category, image, supplier, basePrice, tags, location, sku, moq, stock);
        res.status(201).json({ message: 'Product created successfully', product: newProduct });
    }
    catch{
        res.status(400).json({ error: 'Error creating product' });
    }
}
const commonProducts = async (res, req) => {
    try{
        const{ userId } = req.body;
        const commonProduct = await productService.commonProducts(userId)
        res.status(201).json({ message :'all products for all users', product: commonProduct});
    }
    catch{
        res.status(400).json ({ error: 'Error fetching products'})
    }
}
module.exports = {
    createProduct,commonProducts
};